var searchData=
[
  ['norm_14',['norm',['../class_vector.html#a56de274727442d44f022d8f2fb059e0c',1,'Vector']]],
  ['num_5fof_5fiter_15',['num_of_iter',['../class_stop_criterion.html#a097e4c8dcc639fd90e741b10f5486a2f',1,'StopCriterion']]]
];
