var searchData=
[
  ['quadratic_21',['Quadratic',['../class_quadratic.html',1,'']]]
];
