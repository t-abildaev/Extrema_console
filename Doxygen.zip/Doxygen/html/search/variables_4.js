var searchData=
[
  ['num_5fof_5fiter_53',['num_of_iter',['../class_stop_criterion.html#a097e4c8dcc639fd90e741b10f5486a2f',1,'StopCriterion']]]
];
