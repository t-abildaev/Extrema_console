var searchData=
[
  ['stopcriterion_38',['StopCriterion',['../class_stop_criterion.html',1,'']]]
];
