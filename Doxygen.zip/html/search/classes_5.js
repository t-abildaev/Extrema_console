var searchData=
[
  ['quadratic_37',['Quadratic',['../class_quadratic.html',1,'']]]
];
