var searchData=
[
  ['quadratic_34',['Quadratic',['../class_quadratic.html',1,'']]]
];
