var searchData=
[
  ['eps_50',['EPS',['../class_method.html#a0ae85cdde0dcd2e253a4832be8807fd0',1,'Method::EPS()'],['../class_stop_criterion.html#a87d403e2b8777c96628b60110c316aa8',1,'StopCriterion::EPS()'],['../class_stop_criterion.html#aa848cdc8c317a0788f3bc2daa9444b18',1,'StopCriterion::eps()']]]
];
