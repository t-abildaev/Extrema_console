var searchData=
[
  ['stopcriterion_25',['StopCriterion',['../class_stop_criterion.html',1,'StopCriterion'],['../class_method.html#a151481d1c41daa378ac1e5aeb0f4e54b',1,'Method::stopCriterion()']]]
];
