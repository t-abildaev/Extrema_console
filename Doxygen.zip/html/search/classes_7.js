var searchData=
[
  ['stopcriterion_42',['StopCriterion',['../class_stop_criterion.html',1,'']]]
];
