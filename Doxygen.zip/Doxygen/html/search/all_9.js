var searchData=
[
  ['operator_2a_18',['operator*',['../class_vector.html#a55c8dd6bb8438c890a6d2921fdeff567',1,'Vector']]],
  ['operator_2b_19',['operator+',['../class_vector.html#aaa442735d1279852d0947df6aeedb78c',1,'Vector::operator+()'],['../class_vector.html#af39d99caea858ff67a4bc57fac9b5b33',1,'Vector::operator+()']]],
  ['optimize_20',['optimize',['../class_method.html#a556ec2fcf43408dbac0a14ef512a02c8',1,'Method::optimize()'],['../class_r_s_s.html#a7759627ef352e11a91fa41993fb6dcd4',1,'RSS::optimize()'],['../class_p_r_c_g.html#acd59126316b2d1e5d9611ba974cf93a2',1,'PRCG::optimize()']]]
];
