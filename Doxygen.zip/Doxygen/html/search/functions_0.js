var searchData=
[
  ['get_5fa_41',['get_a',['../class_rectangle.html#af9a8643c7778beade458ec004946adfb',1,'Rectangle']]],
  ['get_5fb_42',['get_b',['../class_rectangle.html#a8bbf7e53477721e206855bf7b73b3a8e',1,'Rectangle']]]
];
