var searchData=
[
  ['operator_2a_58',['operator*',['../class_vector.html#a55c8dd6bb8438c890a6d2921fdeff567',1,'Vector']]],
  ['operator_2b_59',['operator+',['../class_vector.html#aaa442735d1279852d0947df6aeedb78c',1,'Vector::operator+()'],['../class_vector.html#af39d99caea858ff67a4bc57fac9b5b33',1,'Vector::operator+()']]]
];
