var searchData=
[
  ['vector_27',['Vector',['../class_vector.html',1,'Vector'],['../class_vector.html#a858ff7ad68466053595c3eb38b1d9883',1,'Vector::Vector(int _dimension, double value=0)'],['../class_vector.html#a4af091a5c5d096921f084c2ed3901142',1,'Vector::Vector(double *_coordinates, int _dimension)']]]
];
