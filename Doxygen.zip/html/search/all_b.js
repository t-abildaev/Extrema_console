var searchData=
[
  ['quadratic_23',['Quadratic',['../class_quadratic.html',1,'']]]
];
