var searchData=
[
  ['by_5fdifference_28',['by_difference',['../classby__difference.html',1,'']]],
  ['by_5fgradient_29',['by_gradient',['../classby__gradient.html',1,'']]]
];
